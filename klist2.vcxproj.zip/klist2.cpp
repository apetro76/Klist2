/*--

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Copyright (C) 1999 - 2000  Microsoft Corporation.  All rights reserved.

Module Name:

    klist.c

Abstract:

    Sample program that demonstrates how to:
       query Kerberos ticket cache
       purge Kerberos tickets from cache
       request service ticket

Author:

    David Mowers (davemo)   14-October-98

Revision History:

--*/


//
// Common include files.
//
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <windows.h>
#include <stdio.h>      
#include <stdlib.h>     
#include <conio.h>      
#include <ntsecapi.h>
#define SECURITY_WIN32
#include <security.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>
#include <winsock.h>
#include <locale>
#include <codecvt>


#define INTERACTIVE_PURGE 1
#pragma comment(lib, "Secur32.lib")

#define SEC_SUCCESS(Status) ((Status) >= 0) 

VOID
InitUnicodeString(
    PUNICODE_STRING DestinationString,
    PCWSTR SourceString OPTIONAL
);

VOID
ShowLastError(
    LPSTR szAPI,
    DWORD dwError
);

VOID
ShowNTError(
    LPSTR szAPI,
    NTSTATUS Status
);

BOOL
PackageConnectLookup(
    HANDLE* pLogonHandle,
    ULONG* pPackageId
);

BOOL
ShowTickets(
    HANDLE LogonHandle,
    ULONG PackageId,
    DWORD dwMode
);

BOOL
ShowTgt(
    HANDLE LogonHandle,
    ULONG PackageId
);

DWORD
GetEncodedTicket(
    HANDLE LogonHandle,
    ULONG PackageId,
    wchar_t* Server
);

void PrintEncodedTicketHex(PKERB_EXTERNAL_TICKET pTicket) {
    if (pTicket == nullptr || pTicket->EncodedTicketSize == 0 || pTicket->EncodedTicket == nullptr) {
        std::cerr << "Invalid ticket or no EncodedTicket available." << std::endl;
        return;
    }

    BYTE* encodedTicket = pTicket->EncodedTicket;
    ULONG ticketSize = pTicket->EncodedTicketSize;

    std::cout << "EncodedTicket (Hex Dump):" << std::endl;
    for (ULONG i = 0; i < ticketSize; ++i) {
        std::cout << std::setw(2) << std::setfill('0') << std::hex << static_cast<int>(encodedTicket[i]);
        if ((i + 1) % 16 == 0) {
            std::cout << std::endl;  // New line every 16 bytes
        }
        else {
            std::cout << " ";  // Space between bytes
        }
    }
    std::cout << std::dec << std::endl;  // Reset to decimal format
}

void WriteToCCacheFile(std::ofstream& file, const void* data, size_t size) {
    file.write(static_cast<const char*>(data), size);
}

// Function to write a string to the CCACHE file with its length as a 32-bit integer
void WriteStringToCCacheFile(std::ofstream& file, const std::string& str) {
    uint32_t length = static_cast<uint32_t>(str.length());
    WriteToCCacheFile(file, &length, sizeof(length));
    WriteToCCacheFile(file, str.c_str(), length);
}
std::string ConvertPWSTRToString(PWSTR wideString) {
    // Check if the input is valid
    if (!wideString) {
        return std::string();
    }

    // Get the length of the resulting string
    int bufferLength = WideCharToMultiByte(CP_UTF8, 0, wideString, -1, nullptr, 0, nullptr, nullptr);
    if (bufferLength == 0) {
        // Handle error
        return std::string();
    }

    // Allocate buffer for the resulting string
    std::string narrowString(bufferLength, 0);

    // Perform the conversion
    WideCharToMultiByte(CP_UTF8, 0, wideString, -1, &narrowString[0], bufferLength, nullptr, nullptr);

    // Remove the null terminator added by WideCharToMultiByte
    narrowString.pop_back();

    return narrowString;
}

std::string ConvertUnicodeStringToString(const UNICODE_STRING& uString) {
    // Convert UNICODE_STRING to wide string (wstring)
    std::wstring wstr(uString.Buffer, uString.Length / sizeof(wchar_t));

    // Convert wstring to string (narrow)
    std::string str(wstr.begin(), wstr.end());

    return str;
}

// Function to convert a PKERB_EXTERNAL_NAME to std::string
std::string ConvertKerbExternalNameToString(PKERB_EXTERNAL_NAME pKerbName) {
    std::string result;

    if (!pKerbName || pKerbName->NameCount == 0) {
        return result;
    }

    for (USHORT i = 0; i < pKerbName->NameCount; ++i) {
        std::string namePart = ConvertUnicodeStringToString(pKerbName->Names[i]);
        result += namePart;

        // If there are more parts, separate them with a forward slash (common in Kerberos)
        if (i < pKerbName->NameCount - 1) {
            result += '/';
        }
    }

    return result;
}

std::string ConvertWStringToString(const std::wstring& wstr) {
    // Use the wide-to-byte converter
    std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
    return converter.to_bytes(wstr);
}

int __cdecl
wmain(
    int argc,
    wchar_t* argv[]
)
{

    HANDLE LogonHandle = NULL;
    ULONG PackageId;

    if (argc < 2)
    {
        printf("Usage: %S <tickets | tgt | purge | get> [service principal name(for get)]\n", argv[0]);
        return FALSE;
    }

    //
    // Get the logon handle and package ID from the
    // Kerberos package
    //
    if (!PackageConnectLookup(&LogonHandle, &PackageId))
        return FALSE;

    if (!_wcsicmp(argv[1], L"tickets"))
    {
        ShowTickets(LogonHandle, PackageId, 0);
    }
    else if (!_wcsicmp(argv[1], L"tgt"))
    {
        ShowTgt(LogonHandle, PackageId);
    }
    else if (!_wcsicmp(argv[1], L"purge"))
    {
        ShowTickets(LogonHandle, PackageId, INTERACTIVE_PURGE);
    }
    else if (!_wcsicmp(argv[1], L"get"))
    {
        if (argc < 3)
        {
            printf("Provide service principal name (SPN) of encoded ticket to retrieve\n");
        }
        else
            GetEncodedTicket(LogonHandle, PackageId, argv[2]);
    }
    else
    {
        printf("Usage: %S <tickets | tgt | purge | get> [service principal name(for get)]\n", argv[0]);
    }

    if (LogonHandle != NULL)
    {
        LsaDeregisterLogonProcess(LogonHandle);
    }

    return TRUE;

}

VOID
PrintKerbName(
    PKERB_EXTERNAL_NAME Name
)
{
    ULONG Index;
    for (Index = 0; Index < Name->NameCount; Index++)
    {
        printf("%wZ", &Name->Names[Index]);
        if ((Index + 1) < Name->NameCount)
            printf("/");
    }
    printf("\n");
}

VOID
PrintTime(
    LPSTR Comment,
    TimeStamp ConvertTime
)
{

    printf("%s", Comment);

    //
    // If the time is infinite,
    //  just say so.
    //
    if (ConvertTime.HighPart == 0x7FFFFFFF && ConvertTime.LowPart == 0xFFFFFFFF) {
        printf("Infinite\n");

        //
        // Otherwise print it more clearly
        //
    }
    else {

        SYSTEMTIME SystemTime;
        FILETIME LocalFileTime;

        if (FileTimeToLocalFileTime(
            (PFILETIME)&ConvertTime,
            &LocalFileTime
        ) &&
            FileTimeToSystemTime(
                &LocalFileTime,
                &SystemTime
            ))
        {

            printf("%ld/%ld/%ld %ld:%2.2ld:%2.2ld\n",
                SystemTime.wMonth,
                SystemTime.wDay,
                SystemTime.wYear,
                SystemTime.wHour,
                SystemTime.wMinute,
                SystemTime.wSecond);
        }
        else
        {
            printf("%ld\n", (long)(ConvertTime.QuadPart / (10 * 1000 * 1000)));
        }
    }

}

VOID
PrintEType(
    int etype
)
{

#define AddEtype(n) { n, TEXT(#n) }

    struct _etype {
        int etype;
        LPCTSTR ename;
    } enames[] = {
        AddEtype(KERB_ETYPE_NULL),
        AddEtype(KERB_ETYPE_DES_CBC_CRC),
        AddEtype(KERB_ETYPE_DES_CBC_MD4),
        AddEtype(KERB_ETYPE_DES_CBC_MD5),
        AddEtype(KERB_ETYPE_DES_PLAIN),
        AddEtype(KERB_ETYPE_RC4_MD4),
        AddEtype(KERB_ETYPE_RC4_PLAIN2),
        AddEtype(KERB_ETYPE_RC4_LM),
        AddEtype(KERB_ETYPE_RC4_SHA),
        AddEtype(KERB_ETYPE_DES_PLAIN),
        AddEtype(KERB_ETYPE_RC4_HMAC_OLD),
        AddEtype(KERB_ETYPE_RC4_PLAIN_OLD),
        AddEtype(KERB_ETYPE_RC4_HMAC_OLD_EXP),
        AddEtype(KERB_ETYPE_RC4_PLAIN_OLD_EXP),
        AddEtype(KERB_ETYPE_RC4_PLAIN),
        AddEtype(KERB_ETYPE_RC4_PLAIN_EXP),
        AddEtype(KERB_ETYPE_DSA_SIGN),
        AddEtype(KERB_ETYPE_RSA_PRIV),
        AddEtype(KERB_ETYPE_RSA_PUB),
        AddEtype(KERB_ETYPE_RSA_PUB_MD5),
        AddEtype(KERB_ETYPE_RSA_PUB_SHA1),
        AddEtype(KERB_ETYPE_PKCS7_PUB),
        AddEtype(KERB_ETYPE_DES_CBC_MD5_NT),
        AddEtype(KERB_ETYPE_RC4_HMAC_NT),
        AddEtype(KERB_ETYPE_RC4_HMAC_NT_EXP),
        {-1, 0}
    };
    int i;

    for (i = 0; enames[i].ename != 0; i++) {
        if (etype == enames[i].etype) {
            printf("KerbTicket Encryption Type: (%d) %S\n",
                etype,
                enames[i].ename);
            return;
        }
    }
    printf("KerbTicket Encryption Type: %d\n", etype);
}

void write_ccache_header(std::ofstream& ccache_file, int32_t seconds_offset, int32_t microseconds_offset) {
    // Step 1: Header length (12 bytes: 2 for tag, 2 for length, 8 for value)
    uint16_t header_length = htons(12);
    ccache_file.write(reinterpret_cast<const char*>(&header_length), sizeof(header_length));

    // Step 2: Field 1
    uint16_t tag = htons(1);  // Tag value for time offset
    ccache_file.write(reinterpret_cast<const char*>(&tag), sizeof(tag));

    uint16_t length = htons(8);  // Length of the value
    ccache_file.write(reinterpret_cast<const char*>(&length), sizeof(length));

    int32_t sec_offset = htonl(seconds_offset);  // Time offset in seconds
    int32_t usec_offset = htonl(microseconds_offset);  // Time offset in microseconds
    ccache_file.write(reinterpret_cast<const char*>(&sec_offset), sizeof(sec_offset));
    ccache_file.write(reinterpret_cast<const char*>(&usec_offset), sizeof(usec_offset));
}

void convert_large_integer_to_time(LARGE_INTEGER timeSkew, int32_t& seconds, int32_t& microseconds) {
    // Convert to 64-bit integer (in 100-nanosecond intervals)
    int64_t totalTime = timeSkew.QuadPart;

    // Convert to seconds
    seconds = static_cast<int32_t>(totalTime / 10000000); // 10 million 100ns intervals in a second

    // Convert remaining to microseconds
    microseconds = static_cast<int32_t>((totalTime % 10000000) / 10); // Convert remaining 100ns intervals to microseconds
}


VOID
PrintTktFlags(
    ULONG flags
)
{
    if (flags & KERB_TICKET_FLAGS_forwardable) {
        printf("forwardable ");
    }
    if (flags & KERB_TICKET_FLAGS_forwarded) {
        printf("forwarded ");
    }
    if (flags & KERB_TICKET_FLAGS_proxiable) {
        printf("proxiable ");
    }
    if (flags & KERB_TICKET_FLAGS_proxy) {
        printf("proxy ");
    }
    if (flags & KERB_TICKET_FLAGS_may_postdate) {
        printf("may_postdate ");
    }
    if (flags & KERB_TICKET_FLAGS_postdated) {
        printf("postdated ");
    }
    if (flags & KERB_TICKET_FLAGS_invalid) {
        printf("invalid ");
    }
    if (flags & KERB_TICKET_FLAGS_renewable) {
        printf("renewable ");
    }
    if (flags & KERB_TICKET_FLAGS_initial) {
        printf("initial ");
    }
    if (flags & KERB_TICKET_FLAGS_hw_authent) {
        printf("hw_auth ");
    }
    if (flags & KERB_TICKET_FLAGS_pre_authent) {
        printf("preauth ");
    }
    if (flags & KERB_TICKET_FLAGS_ok_as_delegate) {
        printf("delegate ");
    }
    printf("\n");
}

BOOL
PackageConnectLookup(
    HANDLE* pLogonHandle,
    ULONG* pPackageId
)
{
    LSA_STRING Name;
    NTSTATUS Status;

    Status = LsaConnectUntrusted(
        pLogonHandle
    );

    if (!SEC_SUCCESS(Status))
    {
        ShowNTError((LPSTR)"LsaConnectUntrusted", Status);
        return FALSE;
    }

    //Name.Buffer = MICROSOFT_KERBEROS_NAME_A;
    Name.Buffer = (PCHAR)"Kerberos";
    Name.Length = strlen(Name.Buffer);
    Name.MaximumLength = Name.Length + 1;

    Status = LsaLookupAuthenticationPackage(
        *pLogonHandle,
        &Name,
        pPackageId
    );

    if (!SEC_SUCCESS(Status))
    {
        ShowNTError((LPSTR)"LsaLookupAuthenticationPackage", Status);
        return FALSE;
    }

    return TRUE;

}

BOOL
PurgeTicket(
    HANDLE LogonHandle,
    ULONG PackageId,
    LPWSTR Server,
    DWORD  cbServer,
    LPWSTR Realm,
    DWORD  cbRealm
)
{
    NTSTATUS Status;
    PVOID Response;
    ULONG ResponseSize;
    NTSTATUS SubStatus = 0;

    PKERB_PURGE_TKT_CACHE_REQUEST pCacheRequest = NULL;

    pCacheRequest = (PKERB_PURGE_TKT_CACHE_REQUEST)
        LocalAlloc(LMEM_ZEROINIT,
            cbServer + cbRealm + sizeof(KERB_PURGE_TKT_CACHE_REQUEST));

    pCacheRequest->MessageType = KerbPurgeTicketCacheMessage;
    pCacheRequest->LogonId.LowPart = 0;
    pCacheRequest->LogonId.HighPart = 0;

    CopyMemory((LPBYTE)pCacheRequest + sizeof(KERB_PURGE_TKT_CACHE_REQUEST),
        Server, cbServer);
    CopyMemory((LPBYTE)pCacheRequest + sizeof(KERB_PURGE_TKT_CACHE_REQUEST) + cbServer,
        Realm, cbRealm);

    pCacheRequest->ServerName.Buffer =
        (LPWSTR)((LPBYTE)pCacheRequest + sizeof(KERB_PURGE_TKT_CACHE_REQUEST));

    pCacheRequest->ServerName.Length =
        (unsigned short)cbServer;

    pCacheRequest->ServerName.MaximumLength =
        (unsigned short)cbServer;

    pCacheRequest->RealmName.Buffer =
        (LPWSTR)((LPBYTE)pCacheRequest + sizeof(KERB_PURGE_TKT_CACHE_REQUEST) + cbServer);

    pCacheRequest->RealmName.Length =
        (unsigned short)cbRealm;

    pCacheRequest->RealmName.MaximumLength =
        (unsigned short)cbRealm;

    printf("\tDeleting ticket: \n");
    printf("\t   ServerName = %wZ (cb=%lu)\n", &pCacheRequest->ServerName, cbServer);
    printf("\t   RealmName  = %wZ (cb=%lu)\n", &pCacheRequest->RealmName, cbRealm);

    Status = LsaCallAuthenticationPackage(
        LogonHandle,
        PackageId,
        pCacheRequest,
        sizeof(KERB_PURGE_TKT_CACHE_REQUEST) + cbServer + cbRealm,
        &Response,
        &ResponseSize,
        &SubStatus
    );

    if (!SEC_SUCCESS(Status) || !SEC_SUCCESS(Status))
    {
        ShowNTError((LPSTR)"LsaCallAuthenticationPackage(purge)", Status);
        printf("Substatus: 0x%x\n", SubStatus);
        ShowNTError((LPSTR)"LsaCallAuthenticationPackage(purge SubStatus)", SubStatus);
        return FALSE;
    }
    else
    {
        printf("\tTicket purged!\n");
        return TRUE;
    }

}


BOOL
ShowTickets(
    HANDLE LogonHandle,
    ULONG PackageId,
    DWORD dwMode
)
{
    NTSTATUS Status;
    KERB_QUERY_TKT_CACHE_REQUEST CacheRequest;
    PKERB_QUERY_TKT_CACHE_RESPONSE CacheResponse = NULL;
    ULONG ResponseSize;
    NTSTATUS SubStatus;
    ULONG Index;
    int ch;

    CacheRequest.MessageType = KerbQueryTicketCacheMessage;
    CacheRequest.LogonId.LowPart = 0;
    CacheRequest.LogonId.HighPart = 0;

    Status = LsaCallAuthenticationPackage(
        LogonHandle,
        PackageId,
        &CacheRequest,
        sizeof(CacheRequest),
        (PVOID*)&CacheResponse,
        &ResponseSize,
        &SubStatus
    );
    if (!SEC_SUCCESS(Status) || !SEC_SUCCESS(SubStatus))
    {
        ShowNTError((LPSTR)"LsaCallAuthenticationPackage", Status);
        printf("Substatus: 0x%x\n", SubStatus);
        return FALSE;
    }

    printf("\nCached Tickets: (%lu)\n", CacheResponse->CountOfTickets);
    for (Index = 0; Index < CacheResponse->CountOfTickets; Index++)
    {
        printf("\n   Server: %wZ@%wZ\n",
            &CacheResponse->Tickets[Index].ServerName,
            &CacheResponse->Tickets[Index].RealmName);
        printf("      ");
        PrintEType(CacheResponse->Tickets[Index].EncryptionType);
        PrintTime((LPSTR)"      End Time: ", CacheResponse->Tickets[Index].EndTime);
        PrintTime((LPSTR)"      Renew Time: ", CacheResponse->Tickets[Index].RenewTime);
        printf("      TicketFlags: (0x%x) ", CacheResponse->Tickets[Index].TicketFlags);
        PrintTktFlags(CacheResponse->Tickets[Index].TicketFlags);
        printf("\n");

        if (dwMode == INTERACTIVE_PURGE)
        {
            printf("Purge? (y/n/q) : ");
            ch = _getche();
            if (ch == 'y' || ch == 'Y')
            {
                printf("\n");
                PurgeTicket(
                    LogonHandle,
                    PackageId,
                    CacheResponse->Tickets[Index].ServerName.Buffer,
                    CacheResponse->Tickets[Index].ServerName.Length,
                    CacheResponse->Tickets[Index].RealmName.Buffer,
                    CacheResponse->Tickets[Index].RealmName.Length
                );
            }
            else if (ch == 'q' || ch == 'Q')
                goto cleanup;
            else
                printf("\n\n");

        }
    }

cleanup:

    if (CacheResponse != NULL)
    {
        LsaFreeReturnBuffer(CacheResponse);
    }

    return TRUE;
}

BOOL
ShowTgt(
    HANDLE LogonHandle,
    ULONG PackageId
)
{
    NTSTATUS Status;
    KERB_QUERY_TKT_CACHE_REQUEST CacheRequest;
    PKERB_RETRIEVE_TKT_RESPONSE TicketEntry = NULL;
    PKERB_EXTERNAL_TICKET Ticket;
    ULONG ResponseSize;
    NTSTATUS SubStatus;
    BOOLEAN Trusted = TRUE;

    CacheRequest.MessageType = KerbRetrieveTicketMessage;
    CacheRequest.LogonId.LowPart = 0;
    CacheRequest.LogonId.HighPart = 0;

    Status = LsaCallAuthenticationPackage(
        LogonHandle,
        PackageId,
        &CacheRequest,
        sizeof(CacheRequest),
        (PVOID*)&TicketEntry,
        &ResponseSize,
        &SubStatus
    );

    if (!SEC_SUCCESS(Status) || !SEC_SUCCESS(SubStatus))
    {
        ShowNTError((LPSTR)"LsaCallAuthenticationPackage", Status);
        printf("Substatus: 0x%x\n", SubStatus);
        return FALSE;
    }

    Ticket = &(TicketEntry->Ticket);

    printf("\nCached TGT:\n\n");

    printf("ServiceName: "); PrintKerbName(Ticket->ServiceName);

    printf("TargetName: "); PrintKerbName(Ticket->TargetName);

    printf("FullServiceName: "); PrintKerbName(Ticket->ClientName);

    printf("DomainName: %.*S\n",
        Ticket->DomainName.Length / sizeof(WCHAR), Ticket->DomainName.Buffer);

    printf("TargetDomainName: %.*S\n",
        Ticket->TargetDomainName.Length / sizeof(WCHAR), Ticket->TargetDomainName.Buffer);

    printf("AltTargetDomainName: %.*S\n",
        Ticket->AltTargetDomainName.Length / sizeof(WCHAR), Ticket->AltTargetDomainName.Buffer);

    printf("TicketFlags: (0x%x) ", Ticket->TicketFlags);
    PrintTktFlags(Ticket->TicketFlags);
    PrintTime((LPSTR)"KeyExpirationTime: ", Ticket->KeyExpirationTime);
    PrintTime((LPSTR)"StartTime: ", Ticket->StartTime);
    PrintTime((LPSTR)"EndTime: ", Ticket->EndTime);
    PrintTime((LPSTR)"RenewUntil: ", Ticket->RenewUntil);
    PrintTime((LPSTR)"TimeSkew: ", Ticket->TimeSkew);
    PrintEType(Ticket->SessionKey.KeyType);
    PrintEncodedTicketHex(Ticket);

    std::ofstream ccacheFile("krb5_cc", std::ios::binary);
    if (!ccacheFile) {
        std::cerr << "Error: Could not create CCACHE file." << std::endl;
        return false;
    }
    //uint32_t ccacheVersion = htonl(0x0400); // Assuming version 5.4
    uint8_t ccacheVersion[2] = { 0x05, 0x04 };
    WriteToCCacheFile(ccacheFile, reinterpret_cast<const char*>(&ccacheVersion), sizeof(ccacheVersion));

    //int32_t seconds_offset = Ticket->TimeSkew;
    int32_t seconds = 0;
    int32_t microseconds = 0;

    convert_large_integer_to_time(Ticket->TimeSkew, seconds, microseconds);
    write_ccache_header(ccacheFile, seconds, microseconds);


    uint32_t nameType = htonl(0x00000001); // Assuming type 1 for a user principal
    WriteToCCacheFile(ccacheFile, &nameType, sizeof(nameType));

    uint32_t componentCount = htonl(1); // Assuming 1 component (e.g., "user")
    WriteToCCacheFile(ccacheFile, &componentCount, sizeof(componentCount));

    std::string realm = ConvertPWSTRToString(Ticket->DomainName.Buffer);
    uint32_t realmLength = htonl(realm.size());
    WriteToCCacheFile(ccacheFile, &realmLength, sizeof(realmLength));
    WriteStringToCCacheFile(ccacheFile, realm);

    std::wstring clientNameWStr(Ticket->ClientName->Names[0].Buffer, Ticket->ClientName->Names[0].Length / sizeof(wchar_t));
    std::string clientName = ConvertWStringToString(clientNameWStr);
    uint32_t clientNameLength = htonl(clientName.size());
    WriteToCCacheFile(ccacheFile, &clientNameLength, sizeof(clientNameLength));
    WriteStringToCCacheFile(ccacheFile, clientName);


    //PKERB_EXTERNAL_NAME client = Ticket->ClientName;
    uint32_t cnType = htonl(Ticket->ClientName->NameType);
    WriteToCCacheFile(ccacheFile, &cnType, sizeof(cnType));
    componentCount = htonl(Ticket->ClientName->NameCount);
    WriteToCCacheFile(ccacheFile, &componentCount, sizeof(componentCount));
    WriteToCCacheFile(ccacheFile, &realmLength, sizeof(realmLength));
    WriteStringToCCacheFile(ccacheFile, realm);
    WriteToCCacheFile(ccacheFile, &clientNameLength, sizeof(clientNameLength));
    WriteStringToCCacheFile(ccacheFile, clientName);

  
    //PKERB_EXTERNAL_NAME server = Ticket->TargetName;
    nameType = htonl(Ticket->TargetName->NameType);
    WriteToCCacheFile(ccacheFile, &nameType, sizeof(nameType));
    componentCount = htonl(Ticket->TargetName->NameCount);
    WriteToCCacheFile(ccacheFile, &componentCount, sizeof(componentCount));
    realm = ConvertPWSTRToString(Ticket->TargetDomainName.Buffer);
    realmLength = Ticket->TargetDomainName.Length;
    WriteToCCacheFile(ccacheFile, &realmLength, sizeof(realmLength));
    WriteStringToCCacheFile(ccacheFile, realm);
    

    for (int i = 0; i < componentCount; i++) {

        uint32_t l = Ticket->TargetName->Names[i].Length;
        WriteToCCacheFile(ccacheFile, &l, sizeof(l));
        std::wstring targetNameWStr(Ticket->TargetName->Names[i].Buffer, Ticket->TargetName->Names[i].Length / sizeof(wchar_t));
        std::string targetName = ConvertWStringToString(targetNameWStr);
        WriteStringToCCacheFile(ccacheFile, targetName);

    }

    LONG keytype32 = Ticket->SessionKey.KeyType; // 32-bit LONG value from KERB_CRYPTO_KEY
    uint16_t keytype16 = static_cast<uint16_t>(keytype32);
    keytype16 = htons(keytype16);
    WriteToCCacheFile(ccacheFile, &keytype16, sizeof(keytype16));

    uint32_t keylength = Ticket->SessionKey.Length;
    WriteToCCacheFile(ccacheFile, &keylength, sizeof(keylength));
    WriteToCCacheFile(ccacheFile, Ticket->SessionKey.Value, keylength);

    FILETIME fileTime;
    fileTime.dwLowDateTime = Ticket->StartTime.LowPart;
    fileTime.dwHighDateTime = Ticket->StartTime.HighPart;

    const uint64_t EPOCH_DIFFERENCE = 116444736000000000ULL; // Difference between 1970 and 1601 in 100-nanoseconds

// Convert FILETIME to 64-bit integer
    uint64_t time = ((uint64_t)fileTime.dwHighDateTime << 32) + fileTime.dwLowDateTime;

    // Convert to Unix time (seconds since 1970)
    time = (time - EPOCH_DIFFERENCE) / 10000000ULL;

    // Truncate to 32-bit if necessary
    uint32_t startTime32 = static_cast<uint32_t>(time);

    startTime32 = htonl(startTime32); // Convert to big-endian
    WriteToCCacheFile(ccacheFile, &startTime32, sizeof(startTime32));
    WriteToCCacheFile(ccacheFile, &startTime32, sizeof(startTime32));


    fileTime.dwLowDateTime = Ticket->EndTime.LowPart;
    fileTime.dwHighDateTime = Ticket->EndTime.HighPart;

    time = ((uint64_t)fileTime.dwHighDateTime << 32) + fileTime.dwLowDateTime;
    time = (time - EPOCH_DIFFERENCE) / 10000000ULL;
    uint32_t endTime32 = static_cast<uint32_t>(time);
    endTime32 = htonl(endTime32);
    WriteToCCacheFile(ccacheFile, &endTime32, sizeof(endTime32));

    fileTime.dwLowDateTime = Ticket->RenewUntil.LowPart;
    fileTime.dwHighDateTime = Ticket->RenewUntil.HighPart;
    time = ((uint64_t)fileTime.dwHighDateTime << 32) + fileTime.dwLowDateTime;
    time = (time - EPOCH_DIFFERENCE) / 10000000ULL;
    uint32_t RenewTime = static_cast<uint32_t>(time);
    RenewTime = htonl(RenewTime);
    WriteToCCacheFile(ccacheFile, &RenewTime, sizeof(RenewTime));

    uint8_t isSkey = 0; // Set to 0 for a non-session key ticket, which is the usual case
    WriteToCCacheFile(ccacheFile, &isSkey, sizeof(isSkey));

    uint32_t tf = Ticket->TicketFlags;
    WriteToCCacheFile(ccacheFile, &tf, sizeof(tf));

    uint32_t addressCount = htonl(0); // No addresses
    WriteToCCacheFile(ccacheFile, &addressCount, sizeof(addressCount));

    uint32_t authDataCount = htonl(0); // No authdata
    WriteToCCacheFile(ccacheFile, &authDataCount, sizeof(authDataCount));

    uint32_t ticketSize = htonl(Ticket->EncodedTicketSize);
    WriteToCCacheFile(ccacheFile, &ticketSize, sizeof(&ticketSize));
    WriteToCCacheFile(ccacheFile, Ticket->EncodedTicket, Ticket->EncodedTicketSize);




    /*uint16_t numComponents = htons(1); // Assuming a single component
    WriteToCCacheFile(ccacheFile, &numComponents, sizeof(numComponents));

    std::string realm = ConvertPWSTRToString(Ticket->DomainName.Buffer);
    WriteStringToCCacheFile(ccacheFile, realm);


    std::string clientNameString = ConvertKerbExternalNameToString(Ticket->ClientName);
    WriteStringToCCacheFile(ccacheFile, clientNameString);

    uint32_t ticketFlags = htonl(Ticket->TicketFlags);
    WriteToCCacheFile(ccacheFile, &ticketFlags, sizeof(ticketFlags));

    uint16_t keyType = htons(Ticket->SessionKey.KeyType);
    uint16_t keyLength = htons(Ticket->SessionKey.Length);
    WriteToCCacheFile(ccacheFile, &keyType, sizeof(keyType));
    WriteToCCacheFile(ccacheFile, &keyLength, sizeof(keyLength));
    WriteToCCacheFile(ccacheFile, Ticket->SessionKey.Value, Ticket->SessionKey.Length);

    uint32_t startTime = htonl(static_cast<uint32_t>(Ticket->StartTime.QuadPart));
    uint32_t endTime = htonl(static_cast<uint32_t>(Ticket->EndTime.QuadPart));
    uint32_t renewTime = htonl(static_cast<uint32_t>(Ticket->RenewUntil.QuadPart));
    WriteToCCacheFile(ccacheFile, &startTime, sizeof(startTime));
    WriteToCCacheFile(ccacheFile, &endTime, sizeof(endTime));
    WriteToCCacheFile(ccacheFile, &renewTime, sizeof(renewTime));

    uint32_t ticketLength = htonl(Ticket->EncodedTicketSize);
    WriteToCCacheFile(ccacheFile, &ticketLength, sizeof(ticketLength));
    WriteToCCacheFile(ccacheFile, Ticket->EncodedTicket, Ticket->EncodedTicketSize);*/

    ccacheFile.close();
    std::cout << "CCACHE file created successfully." << std::endl;


    if (TicketEntry != NULL)
    {
        LsaFreeReturnBuffer(TicketEntry);
    }

    return TRUE;
}

DWORD
GetEncodedTicket(
    HANDLE LogonHandle,
    ULONG PackageId,
    wchar_t* Server
)
{
    NTSTATUS Status;
    PKERB_RETRIEVE_TKT_REQUEST CacheRequest = NULL;
    PKERB_RETRIEVE_TKT_RESPONSE CacheResponse = NULL;
    PKERB_EXTERNAL_TICKET Ticket;
    ULONG ResponseSize;
    NTSTATUS SubStatus;
    BOOLEAN Trusted = TRUE;
    BOOLEAN Success = FALSE;
    UNICODE_STRING Target = { 0 };
    UNICODE_STRING Target2 = { 0 };

    InitUnicodeString(&Target2, Server);

    CacheRequest = (PKERB_RETRIEVE_TKT_REQUEST)
        LocalAlloc(LMEM_ZEROINIT, Target2.Length + sizeof(KERB_RETRIEVE_TKT_REQUEST));

    CacheRequest->MessageType = KerbRetrieveEncodedTicketMessage;
    CacheRequest->LogonId.LowPart = 0;
    CacheRequest->LogonId.HighPart = 0;


    Target.Buffer = (LPWSTR)(CacheRequest + 1);
    Target.Length = Target2.Length;
    Target.MaximumLength = Target2.MaximumLength;

    CopyMemory(
        Target.Buffer,
        Target2.Buffer,
        Target2.Length
    );

    CacheRequest->TargetName = Target;

    Status = LsaCallAuthenticationPackage(
        LogonHandle,
        PackageId,
        CacheRequest,
        Target2.Length + sizeof(KERB_RETRIEVE_TKT_REQUEST),
        (PVOID*)&CacheResponse,
        &ResponseSize,
        &SubStatus
    );

    if (!SEC_SUCCESS(Status) || !SEC_SUCCESS(SubStatus))
    {
        ShowNTError((LPSTR)"LsaCallAuthenticationPackage", Status);
        printf("Substatus: 0x%x\n", SubStatus);
        ShowNTError((LPSTR)"Substatus:", SubStatus);

    }
    else
    {
        Ticket = &(CacheResponse->Ticket);

        printf("\nEncoded Ticket:\n\n");

        printf("ServiceName: "); PrintKerbName(Ticket->ServiceName);

        printf("TargetName: "); PrintKerbName(Ticket->TargetName);

        printf("ClientName: "); PrintKerbName(Ticket->ClientName);

        printf("DomainName: %.*S\n",
            Ticket->DomainName.Length / sizeof(WCHAR), Ticket->DomainName.Buffer);

        printf("TargetDomainName: %.*S\n",
            Ticket->TargetDomainName.Length / sizeof(WCHAR), Ticket->TargetDomainName.Buffer);

        printf("AltTargetDomainName: %.*S\n",
            Ticket->AltTargetDomainName.Length / sizeof(WCHAR), Ticket->AltTargetDomainName.Buffer);

        printf("TicketFlags: (0x%x) ", Ticket->TicketFlags);
        PrintTktFlags(Ticket->TicketFlags);
        PrintTime((LPSTR)"KeyExpirationTime: ", Ticket->KeyExpirationTime);
        PrintTime((LPSTR)"StartTime: ", Ticket->StartTime);
        PrintTime((LPSTR)"EndTime: ", Ticket->EndTime);
        PrintTime((LPSTR)"RenewUntil: ", Ticket->RenewUntil);
        PrintTime((LPSTR)"TimeSkew: ", Ticket->TimeSkew);
        PrintEType(Ticket->SessionKey.KeyType);

        Success = TRUE;

    }

    if (CacheResponse)
    {
        LsaFreeReturnBuffer(CacheResponse);
    }
    if (CacheRequest)
    {
        LocalFree(CacheRequest);
    }

    return Success;
}

VOID
InitUnicodeString(
    PUNICODE_STRING DestinationString,
    PCWSTR SourceString OPTIONAL
)
{
    ULONG Length;

    DestinationString->Buffer = (PWSTR)SourceString;
    if (SourceString != NULL) {
        Length = wcslen(SourceString) * sizeof(WCHAR);
        DestinationString->Length = (USHORT)Length;
        DestinationString->MaximumLength = (USHORT)(Length + sizeof(UNICODE_NULL));
    }
    else {
        DestinationString->MaximumLength = 0;
        DestinationString->Length = 0;
    }
}

VOID
ShowLastError(
    LPSTR szAPI,
    DWORD dwError
)
{
#define MAX_MSG_SIZE 256

    static WCHAR szMsgBuf[MAX_MSG_SIZE];
    DWORD dwRes;

    printf("Error calling function %s: %lu\n", szAPI, dwError);

    dwRes = FormatMessage(
        FORMAT_MESSAGE_FROM_SYSTEM,
        NULL,
        dwError,
        MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US),
        szMsgBuf,
        MAX_MSG_SIZE,
        NULL);
    if (0 == dwRes) {
        printf("FormatMessage failed with %d\n", GetLastError());
        ExitProcess(EXIT_FAILURE);
    }

    printf("%S", szMsgBuf);
}

VOID
ShowNTError(
    LPSTR szAPI,
    NTSTATUS Status
)
{
    // 
    // Convert the NTSTATUS to Winerror. Then call ShowLastError().     
    // 
    ShowLastError(szAPI, LsaNtStatusToWinError(Status));
}